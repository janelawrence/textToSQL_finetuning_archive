1. Job [] is trained with schema version 2 which includes foreign keys summary in the input, 
did not add "<" to the tokenizer